package com.example.prisonrwanda.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import org.springframework.format.annotation.DateTimeFormat;
import java.util.Date;

@Entity
public class Prisons {
    @Id
    private String id;
    private String fName;
    private String prisonName;

    private String lName;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date satart_date;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date end_date;

    private String image;

    private String doc;

    public Prisons() {
    }

    public Prisons(String id, String fName, String prisonName, String lName, Date satart_date, Date end_date, String image, String doc) {
        this.id = id;
        this.fName = fName;
        this.prisonName = prisonName;
        this.lName = lName;
        this.satart_date = satart_date;
        this.end_date = end_date;
        this.image = image;
        this.doc = doc;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getPrisonName() {
        return prisonName;
    }

    public void setPrisonName(String prisonName) {
        this.prisonName = prisonName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public Date getSatart_date() {
        return satart_date;
    }

    public void setSatart_date(Date satart_date) {
        this.satart_date = satart_date;
    }

    public Date getEnd_date() {
        return end_date;
    }

    public void setEnd_date(Date end_date) {
        this.end_date = end_date;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDoc() {
        return doc;
    }

    public void setDoc(String doc) {
        this.doc = doc;
    }
}
