package com.example.prisonrwanda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrisonRwandaApplication {

    public static void main(String[] args) {
        SpringApplication.run(PrisonRwandaApplication.class, args);
    }

}
