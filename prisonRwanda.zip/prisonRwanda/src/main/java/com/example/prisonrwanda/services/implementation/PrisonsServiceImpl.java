package com.example.prisonrwanda.services.implementation;
import com.example.prisonrwanda.model.Prisons;
import com.example.prisonrwanda.repository.PrisonsRepository;
import com.example.prisonrwanda.services.PrisonsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PrisonsServiceImpl implements PrisonsService {

    @Autowired
    PrisonsRepository prisonsRepository;

    @Override
    public Prisons registerStudent(Prisons stud) {
        return prisonsRepository.save(stud);
    }

    @Override
    public Prisons updateStudent(Prisons stud) {
      return prisonsRepository.save(stud);
    }

    @Override
    public void deleteStudent(String stud) {
        prisonsRepository.deleteById(stud);
    }


    @Override
    public List<Prisons> studentList() {
        return prisonsRepository.findAll();
    }

    @Override
    public Prisons findStudentByStudentId(String stud) {
        return prisonsRepository.findById(stud).get();
    }
}
