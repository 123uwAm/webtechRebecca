package com.example.prisonrwanda.repository;

import com.example.prisonrwanda.model.Signup;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SignupRepository extends JpaRepository <Signup,String>{
}
