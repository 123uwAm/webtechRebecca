package com.example.prisonrwanda.controller;
import com.example.prisonrwanda.model.Prisons;
import com.example.prisonrwanda.services.implementation.PrisonsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PrisonsController {

    @Autowired
    PrisonsServiceImpl prisonServicce;

    @GetMapping("/home")
    public String homePage(Model model){

        model.addAttribute("home", prisonServicce.studentList());

        return "home-page";
    }
@GetMapping("/inde")
    public String ind(){
        return "index";
    }

    @GetMapping("/te")
    public String d(){
        return "temp";
    }
    @GetMapping("/registration")
    public String registerStudentPage(Model model){
        Prisons stud = new Prisons();
        model.addAttribute("student", stud);
        return "registrar";
    }
    @GetMapping("/student-page")
    public String studentpage(Model model){
        Prisons stud = new Prisons();
        model.addAttribute("student", stud);
        return "student";
    }

    @PostMapping("/register")
    public String registerStudentInDb(@ModelAttribute("student") Prisons thePrisons){
        Prisons savedPrisons = prisonServicce.registerStudent(thePrisons);
        if(savedPrisons != null){
            return "redirect:/registration";
        }
        return "redirect:/registration";
    }
    @PostMapping("/register1")
    public String registerStudentInb(@ModelAttribute("student") Prisons thePrisons){
        Prisons savedPrisons = prisonServicce.registerStudent(thePrisons);
        if(savedPrisons != null){
            return "redirect:/student-page";
        }
        return "redirect:/student-page";
    }
    @GetMapping("/home/update/{id}")
    public String editStudent(@PathVariable String id, Model model){
        model.addAttribute("student", prisonServicce.findStudentByStudentId(id));
        return "update";
    }
      @PostMapping("/home/{id}")
    public String updateStudent(@PathVariable String id,
                                @ModelAttribute("student") Prisons prisons, Model model)
      {
          Prisons existingPrisons = prisonServicce.findStudentByStudentId(id);
          existingPrisons.setId(prisons.getId());
          existingPrisons.setfName(prisons.getfName());
          existingPrisons.setlName(prisons.getlName());
          existingPrisons.setEnd_date(prisons.getEnd_date());
          existingPrisons.setSatart_date(prisons.getSatart_date());
          existingPrisons.setDoc(prisons.getDoc());
          existingPrisons.setImage(prisons.getImage());
          existingPrisons.setPrisonName(prisons.getPrisonName());
          prisonServicce.updateStudent(existingPrisons);
           return "redirect:/home";

      }
 @GetMapping("/home/{id}")
    public String deleteStudent(@PathVariable String id)
 {
     prisonServicce.deleteStudent(id);
     return "redirect:/home";
 }
 @GetMapping("/sear")
 public String search(Model model)
 {
     Prisons prisons =new Prisons();
     model.addAttribute("search", prisons);

     return "search";
 }
 @PostMapping("/sear")
 public String searchh(@ModelAttribute("search") Prisons prisons, Model model)
 {
     Prisons prisons1 = prisonServicce.findStudentByStudentId(prisons.getId());
     if (prisons1 !=null){
         model.addAttribute("student1", prisons1);
         return "search";
     }
     else {
         model.addAttribute("error","this person doesn't exit");
         return "search";
     }

 }

}
