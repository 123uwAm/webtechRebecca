package com.example.prisonrwanda.services;

import com.example.prisonrwanda.model.Prisons;

import java.util.List;

public interface PrisonsService {
    // method signature
    // return value , method name;
    Prisons registerStudent(Prisons stud);
    Prisons updateStudent(Prisons stud);
    void deleteStudent(String stud);
    List<Prisons> studentList();
    Prisons findStudentByStudentId(String stud);
}
