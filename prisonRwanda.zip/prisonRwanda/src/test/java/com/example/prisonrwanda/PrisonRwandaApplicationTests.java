package com.example.prisonrwanda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrisonRwandaApplicationTests {

    @Test
    void contextLoads() {
    }

}
